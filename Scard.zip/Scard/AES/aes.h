#ifndef _AES_H_
#define _AES_H_

#include <stdint.h>

// # zdefiniuj poniższe makra na 1/0, aby włączyć / wyłączyć tryb działania.
//
// CBC włącza szyfrowanie AES w trybie pracy CBC.
// CTR włącza szyfrowanie w trybie licznika.
// EBC włącza podstawowy 16-bajtowy algorytm blokowy EBC. Wszystkie można włączyć jednocześnie.
 
// # ifndef-guard pozwala na skonfigurowanie go przed dołączeniem lub w czasie kompilacji.
#ifndef CBC
  #define CBC 1
#endif

#ifndef ECB
  #define ECB 1
#endif

#ifndef CTR
  #define CTR 1
#endif


#define AES128 1
//#define AES192 1
//#define AES256 1

#define AES_BLOCKLEN 16 // Długość bloku w bajtach - AES to tylko blok 128b

#if defined(AES256) && (AES256 == 1)
    #define AES_KEYLEN 32
    #define AES_keyExpSize 240
#elif defined(AES192) && (AES192 == 1)
    #define AES_KEYLEN 24
    #define AES_keyExpSize 208
#else
    #define AES_KEYLEN 16   // Długość klucza w bajtach
    #define AES_keyExpSize 176
#endif

struct AES_ctx
{
  uint8_t RoundKey[AES_keyExpSize];
#if (defined(CBC) && (CBC == 1)) || (defined(CTR) && (CTR == 1))
  uint8_t Iv[AES_BLOCKLEN];
#endif
};

void AES_init_ctx(struct AES_ctx* ctx, const uint8_t* key);
#if (defined(CBC) && (CBC == 1)) || (defined(CTR) && (CTR == 1))
void AES_init_ctx_iv(struct AES_ctx* ctx, const uint8_t* key, const uint8_t* iv);
void AES_ctx_set_iv(struct AES_ctx* ctx, const uint8_t* iv);
#endif

#if defined(ECB) && (ECB == 1)
// rozmiar bufora to dokładnie AES_BLOCKLEN bajtów;
// potrzebujesz tylko AES_init_ctx, ponieważ IV nie jest używany w EBC
// Uwaga: EBC jest uważany za niezabezpieczony w większości zastosowań
void AES_ECB_encrypt(const struct AES_ctx* ctx, uint8_t* buf);
void AES_ECB_decrypt(const struct AES_ctx* ctx, uint8_t* buf);

#endif // #if defined(ECB) && (ECB == !)


#if defined(CBC) && (CBC == 1)
// rozmiar bufora MUSI być wielokrtonością AES_BLOCKLEN;
// Sugerowane https://en.wikipedia.org/wiki/Padding_(cryptography)#PKCS7 dla schematu dopełnienia
// UWAGI: musisz ustawić IV w ctx przez AES_init_ctx_iv () lub AES_ctx_set_iv ()
// Żaden IV nie powinien być nigdy ponownie używany z tym samym kluczem
void AES_CBC_encrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);
void AES_CBC_decrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);

#endif // #if defined(CBC) && (CBC == 1)


#if defined(CTR) && (CTR == 1)

// Ta sama funkcja do szyfrowania jak do odszyfrowywania.
// IV jest inkrementowane dla każdego bloku i używane po zaszyfrowaniu jako uzupełnienie XOR do wyjścia
// Sugerowane https://en.wikipedia.org/wiki/Padding_(cryptography)#PKCS7 dla schematu dopełnienia
// UWAGI: musisz ustawić IV w ctx za pomocą AES_init_ctx_iv () lub AES_ctx_set_iv ()
// Żaden IV nie powinien być nigdy ponownie używany z tym samym kluczem
void AES_CTR_xcrypt_buffer(struct AES_ctx* ctx, uint8_t* buf, uint32_t length);

#endif // #if defined(CTR) && (CTR == 1)


#endif // _AES_H_
