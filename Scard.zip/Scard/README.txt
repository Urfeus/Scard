SCARD

Program pozwala na wygenerowanie klucza do algorytmu AES128 oraz jego zapis na karcie pamięciowej SLE5542.
Za jego pomocą można również zaszyfrować, a następnie odszyfrować pliki.
Testowany był z czytnikiem ACR39U i na systemie Kali Linux. Tylko z takim zestawem gwarantujemy działanie, aczkolwiek przy korzystaniu z innego czytnik lub innej dystrybucji systemu Linux, również może on działać.

INSTALOWANIE

Razem z programem "scard.c" został dostarczony jeszcze plik "Makefile", który określa z jakimi opcjami należy skompilować program, aby działał poprawnie.
Aby zainstalować program, należy go rozpakować i wejść do folderu scard. Następnie uruchomić polecenie make:

tar -xvf scard.tar
cd ./scard
make

URUCHOMIENIE

Poprawna kompilacja powinna utworzyć plik scard, który jest plikiem wykonywalnym. Aby uruchomić program należy wpisać ./scard w terminalu. Polecenie uruchomione bez żadnych opcji lub z opcją -h wyświetla instrukcję (manual) obsługi programu:

./scard -h

UWAGI I PORADY

Czasami program podczas tworzenia i zapisu klucza na kartę, pomimo zwróconej informacji o poprawnym zapisie, nie zapisuje go. Po użyciu programu z opcją -k (zapis klucza) należy się upewnić, że klucz został zapisany (uruchomić program z opcją -c):

./scard -k
...
./scard -c

Pliki, które określone zostały jako argument opcji -f muszą istnieć. Inaczej program zakończy swoje działanie.

Folder AES zawiera niezbędne do szyfrowania pliki i nie można go usuwać. Musi znajdować się w tym samym folderze co plik wykonywalny scard.


AUTORZY

Autorami tego projektu są:
- Grzegorz Kmita
- Maciej Kasprzyk

Program powstał jako część projektu z Kryptografii na trzecim semestrze kierunku Cyberbezpieczeństwo.