#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <assert.h>
#include <stdarg.h>
#include <getopt.h>
#include <string.h>
#include <time.h>
#include <stdint.h>
#include <winscard.h>
#include "AES/pkcs7_padding.c"
#include "AES/aes.c"

#define CBC 1

#define CHECK(f, rv) \
if (SCARD_S_SUCCESS != rv) {\
    fprintf(stderr, f ": %s\n", pcsc_stringify_error(rv)); \
    return -1; \
}

#define CHECK_RESPONSE(buffer, bufferLength, okCode) \
if (buffer[bufferLength-2] != 0x90 || buffer[bufferLength-1] != okCode) { \
    fprintf(stderr, "Nieprawidlowa odpowiedz karty\n"); \
    return -2; \
}

void err(const int code, const char *msg, ...) {
    /*******************************************************************************
    * Funkcja do wyświetlania błędów programowych.
    ******************************************************************************/
    va_list ap;
    va_start(ap, msg);
    vfprintf(stderr, msg, ap);
    va_end(ap);
    exit(code);
}

void key_gen(char *key){
    /*********************************************************************************
    * Funkcja generująca klucz 32 bitowy. Jako argument przekazuje się wskaźnik
    * do alokowanej w pamięci tablicy typu char. Funkcja nie zwraca żadnych danych
    * ponieważ operuje bezpośrednio na danych, do których został przekazany wskaźnik.
    *********************************************************************************/
    srand(time(NULL));
    int val;
    // 16 B = 128 b - rozmiar klucza
    for(int i=0;i<16;i++){
        val = rand() % (256-33) + 33;
        sprintf(key, "%c",val);
        key += 1;
    }
}

/*******************************************************************************
* TRYB PRACY
* - ENCRYPT - szyfrowanie
* - DECRYPT - deszyfrowanie
* - SET_KEY - generowanie i zapis klucza na karcie
* - CHECK_KEY - odczytanie aktualnie zapisanych danych na karcie
******************************************************************************/
typedef enum mode_enum { 
    ENCRYPT, 
    SET_KEY, 
    DECRYPT, 
    CHECK_KEY 
} esp_t;

extern char *optarg;
extern int optind, opterr, optopt;

void usage(int ec) {
    /*******************************************************************************
    * Funkcja wyświetlająca instrukcję obsługi programu SCARD.
    * Po wyświetleniu program kończy swoje działanie
    ******************************************************************************/
    printf("SCARD manual: \n");
    printf("\nMozesz uzyc programu do szyfrowania / deszyfrowania oraz generowania klucza i danych na karcie\n");
    printf("     [-R <n>]            : użyj czytnika o numerze <n>\n");
    printf("     [-k]                : tryb tworzenia klucza na karcie\n");
    printf("     [-e]                : tryb szyfrowania pliku\n");
    printf("     [-d]                : tryb deszyfrowania pliku\n");
    printf("     [-c]                : tryb sprawdzania zawartości karty\n");
    printf("     [-f <plik>]         : plik do zaszyfrowania\n");
    printf("     [-C <kod (ffffff)>] : uzyj tego kodu do zapisu na karte (domyslnie FFFFFF)\n");
    printf("     [-h]                : wyswielt manual\n\n");
    exit(ec);
}

int main(int argc, char *argv[]) {
    /***********************************************************************************
    * Funkcja główna - tutaj są parsowane argumenty i wykonywane zadanie - szyfrowanie,
    * deszyfrowanie albo tworzenie klucza i zapis na karcie danych właściciela.
    ***********************************************************************************/

    // ZMIENNE POTRZEBNE DO KOMUNIKACJI Z CZYTNIKIEM
    LONG rv;
    SCARDCONTEXT hContext;
    SCARDHANDLE hCard;
    DWORD dwReaders, dwActiveProtocol, dwRecvLength;
    LPTSTR mszReaders;
    SCARD_IO_REQUEST pioSendPci;
    // ALOKOWANIE BUFORA DO PRZECHOWYWANIA DANYCH Z KARTY
    BYTE pbRecvBuffer[266];
    BYTE pbSendBuffer[266];
    // INNE POTRZEBNE ZMIENNE
    unsigned int i, sz, remaining;
    unsigned int length = 256;
    unsigned int nbytes = 0;
    unsigned int msglen = 0;
    char *ptr, **readers = NULL;
    int fd,nbReaders;
    int rid = -1;
    BYTE cmdDefineCardType[] = { 0xFF, 0xA4, 0x00, 0x00, 0x01, 0x06 };
    BYTE cmdWriteCard[] = { 0xFF, 0xD0, 0x00 };
    // DOMYŚLNY KOD DOSTĘPU DO ZAPISU NA KARCIE
    unsigned int writeCode = 0xffffff;
    // DOMYŚLNE PRZESUNIĘCIE - TU ZACZYNA SIĘ ALTERABLE MEMORY
    BYTE offset = 32;
    // TRYB PRACY - zobacz sekcję tryby pracy na początku pliku
    esp_t mode;
    // ZMIENNE POTRZEBNE DO SZYFROWANIA
    char *file_name = "-";
    FILE *message, *encrypted, *pFile;
    long lSize;
    char *buffer, *temp;
    size_t result;
    // WEKTOR IV
    uint8_t iv[]  = { 0x75, 0x52, 0x5f, 0x69, 0x6e, 0x74, 0x65, 0x72, 0x65, 0x73, 0x74, 0x69, 0x6e, 0x67, 0x21, 0x21 };

    // DOMYŚLNIE BUFORY WYPEŁNIONE WARTOŚCIĄ 0
    memset(pbRecvBuffer,0,265);
    memset(pbSendBuffer,0,265);
    memset(&pioSendPci,0,sizeof(SCARD_IO_REQUEST));

    if (argc == 1) {
        usage(0);
    }

    /***********************************************************************************
    * Parsowanie argumentów - jeżeli po danej literze występuje znak :, oznacza to, że 
    * po tej opcji musi wystąpić wartość.
    ***********************************************************************************/
    while ((i = getopt(argc, argv, "hf:edkcR:C:")) != EOF) {
        switch (i) {
        case 'h':
            usage(0);
            break;
        case 'e':
            mode = ENCRYPT;
            break;
        case 'k':
            mode = SET_KEY;
            break;
        case 'd':
            mode = DECRYPT;
            break;
        case 'c':
            mode = CHECK_KEY;
            break;
        case 'f':
            file_name = strdup(optarg);
            break;
        case 'R':
            rid = strtol(optarg, NULL, 10);
            break;
        case 'C':
            writeCode = strtol(optarg, NULL, 16);
            if (writeCode > 0xffffff) {
                err(3, "Nieprawidłowa wartość po -C. Kod musi mieć 3 bajty.\n");
            }
        default:
            usage(3);
            break;
        }
    }



    /***********************************************************************************
    * Wybranie czytnika i nawiązanie komunikacji z nim. Jeżeli jest więcej niż jeden 
    * czytnik, a nie zostało określone w opcji -R, który ma zostać wybrany, to 
    * wylistowanie dostępnych czytników i zakończenie działania programu.
    ***********************************************************************************/

    rv = SCardEstablishContext(SCARD_SCOPE_SYSTEM, NULL, NULL, &hContext);
    CHECK("SCardEstablishContext", rv);
    dwReaders = SCARD_AUTOALLOCATE;
    rv = SCardListReaders(hContext, NULL, (LPTSTR)&mszReaders, &dwReaders);
    CHECK("SCardListReaders", rv)
    nbReaders = 0;
    ptr = mszReaders;
    while (*ptr != '\0') {
        ptr += strlen(ptr)+1;
        nbReaders++;
    }
    if (nbReaders == 0) {err(1, "Nie znaleziono czytnika\n");}
    readers = calloc(nbReaders, sizeof(char *));
    if (NULL == readers) {err(1, "Nie mam pamieci!\n");}
    nbReaders = 0;
    ptr = mszReaders;
    while (*ptr != '\0') {
        readers[nbReaders] = ptr;
        ptr += strlen(ptr)+1;
        nbReaders++;
    }
    if (nbReaders == 1) {
        rid = 0;
    } else if (rid == -1) {
        fprintf(stdout, "Dostępne czytniki (użyj -R do wyboru czytnika): \n");
        for (int i = 0; i < nbReaders; i++) {
            fprintf(stdout, "%d: %s\n", i, readers[i]);
        }
        printf("\n");
        exit(0);
    }
    assert(rid > -1);


    /***********************************************************************************
    * Wybranie czytnika i nawiązanie komunikacji z nim. Jeżeli jest więcej niż jeden 
    * czytnik, a nie zostało określone w opcji -R, który ma zostać wybrany, to 
    * wylistowanie dostępnych czytników i zakończenie działania programu.
    ***********************************************************************************/
        
    rv = SCardConnect(hContext, readers[rid], SCARD_SHARE_DIRECT, SCARD_PROTOCOL_T0 | SCARD_PROTOCOL_T1, &hCard, &dwActiveProtocol);
    CHECK("SCardConnect", rv)
    switch(dwActiveProtocol){
        case SCARD_PROTOCOL_T0:
            pioSendPci = *SCARD_PCI_T0;
            break;
        case SCARD_PROTOCOL_T1:
            pioSendPci = *SCARD_PCI_T1;
            break;
        case SCARD_PROTOCOL_RAW:
            pioSendPci = *SCARD_PCI_RAW;
            break;
        default:
            break;
    }
    dwRecvLength = sizeof(pbRecvBuffer);
    rv = SCardTransmit(hCard, &pioSendPci, cmdDefineCardType, sizeof(cmdDefineCardType), NULL, pbRecvBuffer, &dwRecvLength);
    CHECK("SCardTransmit (define card type)", rv)
    CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);


    /**************************************************************************************
    * Właściwa część programu - w zależności od wybranego trybu szyfrowanie/deszyfrowanie, 
    * ustalanie klucza albo jego sprawdzanie.
    * Jeżeli nie został określony żaden tryb to informacja o wybraniu niepoprawnego trybu
    * i wyświetlenie instrukcji korzystania z programu
    **************************************************************************************/

    if (mode == SET_KEY) {
        // TRYB GEENROWANIA KLUCZA
        printf("Jestes w trybie generowania klucza.\nTwoj klucz zostanie wygenerowany automatycznie i zapisany na karcie\n");


        //DEFINIOWANIE ZMIENNYCH I POBRANIE IMIENIA I NAZWISKA [MAX 48 bajtów]
        char *czas = malloc(sizeof(char)*32);
        char *imienazwisko = malloc(sizeof(char) * 49);
        char *key = malloc(16*sizeof(char));
        printf("Podaj imie i nazwisko: ");
        scanf("%48[^\n]", imienazwisko);


        // SPRAWDZANIE CZY KOD DO ZAPISU NA KARTĘ JEST POPRAWNY
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0x20;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = 0x00;
        pbSendBuffer[4] = 0x03;
        msglen = 8;
        memcpy(&pbSendBuffer[5],&writeCode,3);
        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit (unlock)", rv);
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x07);


        // ZAPIS 128 bitowego KLUCZA [32-48]
        memset(pbSendBuffer,0,265);
        memset(pbRecvBuffer,0,265);
        nbytes = 16; // rozmiar pola do zapisu
        offset = 32; // przesunięcie w pamięci karty
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xD0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset;
        pbSendBuffer[4] = nbytes;
        msglen = 5 + nbytes; // łączna długość wiadomości 5-potrzebne dane w protokole komunikacji z kartą
        key_gen(key);
        memcpy(&pbSendBuffer[5], key, 16);

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv);
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);


        // ZAPIS IMIENIA I NAZWISKA [64-96]
        memset(pbSendBuffer,0,265);
        memset(pbRecvBuffer,0,265);
        nbytes = 48;
        offset = 48;
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xD0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset;
        pbSendBuffer[4] = nbytes;
        msglen = 5 + nbytes;
        memcpy(&pbSendBuffer[5], imienazwisko, strlen(imienazwisko));

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv);
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);


        // ZAPIS DATY [96-128]
        memset(pbSendBuffer,0,265);
        memset(pbRecvBuffer,0,265);
        nbytes = 32; // rozmiar pola do zapisu
        offset = 96; // zaczynamy od offsetu 32
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xD0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset;
        pbSendBuffer[4] = nbytes;
        msglen = 5 + nbytes;

        time_t t = time(NULL);
        struct tm tm = *localtime(&t);
        sprintf(czas, "%d-%02d-%02d %02d:%02d:%02d", tm.tm_year + 1900, tm.tm_mon + 1, tm.tm_mday, tm.tm_hour, tm.tm_min, tm.tm_sec);
        memcpy(&pbSendBuffer[5], czas, strlen(czas));

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv);
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);

        printf("\nUdalo się zapisać klucz oraz dane wlasciciela na karcie.\nAby sprawdzić czy dane na pewno się zapisały uruchom program z opcją -c i sprawdź czy dane się zgadzają\n");
    }
    else if(mode == ENCRYPT || mode == DECRYPT) {

        // INFORMACJA O WYBRANYM TRYBIE
        if (mode == ENCRYPT){printf("SZYFROWANIE\n");}
        else {printf("DESZYFROWANIE\n");}

        // DEFINIOWNIE ZMIENNYCH
        char *aes_key = malloc(16*sizeof(char));
        int sor;

        // ODCZYTANIE KLUCZA
        offset = 32;
        length = 16;
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xB0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset; // tutaj zaczyna się Alterable Memory
        pbSendBuffer[4] = length; // klucz to 256 bitów
        msglen = 5; // dlugosc przesylanych danych

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv)
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);
        sor = dwRecvLength - 2; // size of response
        char *response = malloc(sor * sizeof(char));
        aes_key = response;
        memcpy(response, pbRecvBuffer, sor * sizeof(char));


        // INICJOWANIE AES
        struct AES_ctx ctx;

        if(mode == ENCRYPT){
            // SPRAWDZENIE INSTNIENIA PLIKÓW I UTWORZENIE PLIKÓW DO KTÓRYCH BĘDĄ ZAPISANE DANE
            message = fopen(file_name, "r");
            if(message == NULL){
                printf("Plik do zaszfyrowania musi istnieć!\n");   
                exit(1);      
            }

            // PODZIAŁ NA NAZWĘ I ROZSZERZENIE
            char *ext, *name;
            name = strtok(file_name, ".");
            ext = strtok(NULL, ".");

            // UTWORZENIE NOWEJ NAZWY PLIKU
            temp = malloc((strlen(file_name)+20)*sizeof(char));
            if (ext == NULL) {
                sprintf(temp, "%s_%s",name, "encrypted");
            } else {
                sprintf(temp, "%s_%s.%s",name, "encrypted", ext);
            }

            // UTWORZENIE PLIKU
            encrypted = fopen(temp, "w+");
            if(encrypted == NULL){
                printf("Problem z plikiem z szyfrogramem!\n");   
                exit(1);             
            } 

            // SPRAWDZENIE DŁUGOŚCI PLIKU
            pFile = message;
            fseek(pFile, 0, SEEK_END);
            lSize = ftell(pFile);
            rewind(pFile);

            // INICJOWANIE BUFORA
            buffer = (char *) malloc (sizeof(char) * lSize + 1);
            if (buffer == NULL) {
                fputs("Problem z alokacją pamięci!\n", stderr); 
                exit(2);
            }
            memset(buffer, 0, sizeof(char)*lSize + 1);

            // ODCZYT DANYCH I ZAPIS DO BUFORA
            result = fread(buffer, sizeof(char), lSize, pFile);
            if (result != lSize) {
                fputs("Problem z odczytem!\n", stderr); 
                exit(3);
            }

            int dlen = result;
            int klen = 16;
            int klenu = klen;
            
            // PADDING
            int dlenu = dlen;
            if (dlen % 16) {
                dlenu += 16 - (dlen % 16);
            }

            // DEFINIOWANIE TABLIC DO PRZECHOWYWANIA DANYCH WRAZ Z DOPEŁNIENIEM
            uint8_t hexarray[dlenu];
            uint8_t kexarray[klenu];
            memset( hexarray, 0, dlenu );
            memset( kexarray, 0, klenu );

            // TWORZENIE TABLIC Z WARTOŚCIAMI LICZBOWYMI ZAMIAST ZNAKOWYMI 
            for (int i=0;i<dlen;i++) {hexarray[i] = (uint8_t)buffer[i];}
            for (int i=0;i<klen;i++) {kexarray[i] = (uint8_t)aes_key[i];}

            // STOSOWANIE PADDINGU
            int reportPad = pkcs7_padding_pad_buffer(hexarray, dlen, sizeof(hexarray), 16);
            int keyPad = pkcs7_padding_pad_buffer(kexarray, klen, sizeof(kexarray), 16);
            
            // SZYFROWANIE I ZAPIS DO PLIKU
            AES_init_ctx_iv(&ctx, kexarray, iv);
            AES_CBC_encrypt_buffer(&ctx, hexarray, dlenu);
            fwrite(hexarray, sizeof(hexarray), 1, encrypted);

            // ZAMYKANIE PLIKÓW, ZWALNIANIE PAMIĘCI
            fclose(encrypted);
            fclose(message);
        }
        else if(mode == DECRYPT){
            // SPRAWDZENIE INSTNIENIA PLIKÓW I UTWORZENIE PLIKÓW DO KTÓRYCH BĘDĄ ZAPISANE DANE
            encrypted = fopen(file_name, "rb");
            if(encrypted == NULL){
                printf("Plik do odszyfrowania musi istnieć!\n");   
                exit(1);             
            }

            // PODZIAŁ NA NAZWĘ I ROZSZERZENIE
            char *ext, *name;
            name = strtok(file_name, ".");
            ext = strtok(NULL, ".");

            // UTWORZENIE NOWEJ NAZWY PLIKU
            temp = malloc((strlen(file_name)+20)*sizeof(char));
            if (ext == NULL) {
                sprintf(temp, "%s_%s",name, "decrypted");
            } else {
                sprintf(temp, "%s_%s.%s",name, "decrypted", ext);
            }

            // UTWORZENIE PLIKU
            message = fopen(temp, "w+");
            if(message == NULL){
                printf("Problem z utworzeniem pliku z wiadomością!\n");   
                exit(1);      
            } 
            
            // SPRAWDZENIE DŁUGOŚCI PLIKU
            pFile = encrypted;
            fseek(pFile, 0, SEEK_END);
            lSize = ftell(pFile);
            rewind(pFile);

            // INICJOWANIE BUFORA
            buffer = (char *) malloc (sizeof(char) * lSize + 1);
            if (buffer == NULL) {
                fputs("Problem z alokacją pamięci!\n", stderr); 
                exit(2);
            }
            memset(buffer, 0, sizeof(char)*lSize + 1);

            // ODCZYT DANYCH I ZAPIS DO BUFORA
            result = fread(buffer, sizeof(char), lSize, pFile);
            if (result != lSize) {
                fputs("Problem z odczytem danych!\n", stderr); 
                exit(3);
            }

            int dlen = result;
            int klen = 16;
            int klenu = klen;
            
            // PADDING BUFORA
            int dlenu = dlen;
            if (dlen % 16) {
                dlenu += 16 - (dlen % 16);
            }

            // DEFINIOWANIE TABLIC DO PRZECHOWYWANIA DANYCH WRAZ Z DOPEŁNIENIEM
            uint8_t hexarray[dlenu];
            uint8_t kexarray[klenu];
            memset( hexarray, 0, dlenu );
            memset( kexarray, 0, klenu );

            // TWORZENIE TABLIC Z WARTOŚCIAMI LICZBOWYMI ZAMIAST ZNAKOWYMI 
            for (int i=0;i<dlen;i++) {hexarray[i] = (uint8_t)buffer[i];}
            for (int i=0;i<klen;i++) {kexarray[i] = (uint8_t)aes_key[i];}
            
            // DESZYFROWANIE I ZAPIS DO PLIKU
            AES_init_ctx_iv(&ctx, kexarray, iv);
            AES_CBC_decrypt_buffer(&ctx, hexarray, dlenu);
            fwrite(hexarray, dlenu, 1, message);

            // ZAMYKANIE PLIKÓW, ZWALNIANIE PAMIĘCI
            fclose(encrypted);
            fclose(message);
        }

        printf("Sukces!\n");
        printf("Plik wynikowy: %s\n", temp);

        // ZWALNIANIE ZAREZERWOWANEJ PAMIĘCI
        free(aes_key);
        free(buffer);
        free(temp);
    }
    else if(mode == CHECK_KEY){
        printf("TRYB SPRAWDZANIA ZAWARTOŚCI\n\n");

        // DEFINIOWANIE ZMIENNYCH
        char *aes_key = malloc(16*sizeof(char));
        char *response;
        int sor;

        // ODCZYTANIE KLUCZA
        offset = 32;
        length = 16;
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xB0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset;
        pbSendBuffer[4] = length;
        msglen = 5;

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv)
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);
        sor = dwRecvLength - 2;
        response = malloc(sor * sizeof(char));
        aes_key = response;
        memcpy(response, pbRecvBuffer, sor * sizeof(char));
        fprintf(stdout, "KLUCZ: %s\n", response);

        // ODCZYTANIE IMIENIA I NAZWISKA
        offset = 48;
        length = 48;
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xB0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset;
        pbSendBuffer[4] = length;
        msglen = 5;

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv)
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);
        sor = dwRecvLength - 2;
        response = realloc(response, sor);
        memcpy(response, pbRecvBuffer, sor * sizeof(char));
        fprintf(stdout, "WLASCICIEL: %s\n", response);

        // ODCZYTANIE CZASU UTWORZENIA
        offset = 96;
        length = 32;
        pbSendBuffer[0] = 0xFF;
        pbSendBuffer[1] = 0xB0;
        pbSendBuffer[2] = 0x00;
        pbSendBuffer[3] = offset;
        pbSendBuffer[4] = length;
        msglen = 5;

        dwRecvLength = sizeof(pbRecvBuffer);
        rv = SCardTransmit(hCard, &pioSendPci, pbSendBuffer, msglen, NULL, pbRecvBuffer, &dwRecvLength);
        CHECK("SCardTransmit", rv)
        CHECK_RESPONSE(pbRecvBuffer, dwRecvLength, 0x00);
        sor = dwRecvLength - 2;
        response = realloc(response, sor);
        memcpy(response, pbRecvBuffer, sor * sizeof(char));
        fprintf(stdout, "CZAS UTWORZENIA: %s\n", response);

        // ZWOLNIENIE ZAJMOWANEJ PAMIĘCI
        free(aes_key);
    }
    else {
        err(1, "Wybrałes niepoprawny tryb!\n");
    }


    // ZAKOŃCZENIE PRACY Z KARTĄ

    rv = SCardDisconnect(hCard, SCARD_LEAVE_CARD);
    CHECK("SCardDisconnect", rv);
    rv = SCardFreeMemory(hContext, mszReaders);
    CHECK("SCardFreeMemory", rv);
    rv = SCardReleaseContext(hContext);
    CHECK("SCardReleaseContext", rv);
}
